<?php
/**
 * Created by PhpStorm.
 * User: Diego
 * Date: 18/7/2018
 * Time: 19:40
 */
include_once('clsConexion.php');
class Sucursal extends Conexion
{
    //variables;
    private $idsucursal;
    private $latitud;
    private $longitud;

    /**
     * clsSucursal constructor.
     */
    public function Sucursal()
    {
        parent::Conexion();
        $this->latitud="";
        $this->longitud="";
    }

    /**
     * @return mixed
     */
    public function getIdsucursal()
    {
        return $this->idsucursal;
    }

    /**
     * @param mixed $idsucursal
     */
    public function setIdsucursal($idsucursal)
    {
        $this->idsucursal = $idsucursal;
    }

    /**
     * @return mixed
     */
    public function getLatitud()
    {
        return $this->latitud;
    }

    /**
     * @param mixed $latitud
     */
    public function setLatitud($latitud)
    {
        $this->latitud = $latitud;
    }

    /**
     * @return mixed
     */
    public function getLongitud()
    {
        return $this->longitud;
    }

    /**
     * @param mixed $longitud
     */
    public function setLongitud($longitud)
    {
        $this->longitud = $longitud;
    }
    public function guardar()
    {
        $sql="insert into Sucursal(longitud,latitud) values ('$this->longitud','$this->latitud')";
        if(parent::ejecutar($sql))
        {
            return true;
        }
        else{return false;}
    }
    public function buscar()
    {
        $sql="select *from Sucursal";
        return parent::ejecutar($sql);
    }

}
?>